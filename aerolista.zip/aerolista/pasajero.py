# Clase Pasajero (paso 25)
# ==============================================================
#  pasajero.py  ·  Modelo de datos de cada reserva/pasajero
# ==============================================================

from vuelo import clase_de_asiento


class Pasajero:
    def __init__(self, numero, nombre, cedula, edad, asiento, clase=None):
        self.numero = int(numero)
        self.nombre = str(nombre).strip()
        self.cedula = str(cedula).strip()
        self.edad = int(edad)
        self.asiento = str(asiento).strip().upper()
        self.clase = clase if clase else clase_de_asiento(self.asiento)

    def to_dict(self):
        return {
            "numero": self.numero,
            "nombre": self.nombre,
            "cedula": self.cedula,
            "edad": self.edad,
            "asiento": self.asiento,
            "clase": self.clase,
        }

    def a_diccionario(self):
        return self.to_dict()

    @classmethod
    def from_dict(cls, data):
        return cls(
            numero=data["numero"],
            nombre=data["nombre"],
            cedula=data["cedula"],
            edad=data["edad"],
            asiento=data["asiento"],
            clase=data.get("clase"),
        )