# ==============================================================
#  app.py  ·  Servidor Flask y API REST de AeroLista
# ==============================================================

from datetime import datetime

from flask import Flask, jsonify, render_template, request
from pasajero import Pasajero
from persistencia import (
    agregar_piloto,
    cargar_facturas,
    cargar_lista,
    cargar_pilotos,
    eliminar_factura,
    eliminar_piloto,
    guardar_factura,
    guardar_lista,
    restaurar_ejemplo,
)
from verificador import verificar_metodos
from vuelo import VUELO, asiento_existe, clase_de_asiento, separar_asiento, total_asientos

app = Flask(__name__)
lista, siguiente_numero = cargar_lista()


def respuesta_ok(datos=None, mensaje="", avisos=None):
    return jsonify({
        "ok": True,
        "datos": datos,
        "mensaje": mensaje,
        "avisos": avisos or [],
    })


def respuesta_error(mensaje, status=400, **extra):
    cuerpo = {"ok": False, "mensaje": mensaje}
    cuerpo.update(extra)
    return jsonify(cuerpo), status


def validar_datos_pasajero(nombre, cedula, edad, asiento, validar_cedula=True):
    if not nombre or len(nombre.strip()) < 2:
        return "Escribe el nombre del pasajero (mínimo 2 caracteres)"
    if validar_cedula and (not cedula or not cedula.isdigit() or len(cedula) != 10):
        return "La cédula debe tener exactamente 10 dígitos"
    try:
        edad_num = int(edad)
    except (TypeError, ValueError):
        return "La edad debe ser un número entero"
    if edad_num < 0 or edad_num > 120:
        return "La edad debe estar entre 0 y 120 años"
    if not asiento_existe(asiento):
        return f"El asiento {asiento} no existe en este avión"
    return ""


def generar_avisos(edad, asiento):
    avisos = []
    fila, _ = separar_asiento(asiento)
    if int(edad) < 18:
        avisos.append("Pasajero menor de edad: debe viajar acompañado por un representante.")
        if fila in VUELO["filas_salida"]:
            avisos.append(f"La fila {fila} es salida de emergencia: se recomienda reubicar al menor.")
    return avisos


@app.get("/")
def inicio():
    return render_template("index.html", vuelo=VUELO)


@app.get("/api/vuelo")
def api_vuelo():
    return respuesta_ok(VUELO)


@app.get("/api/resumen")
def api_resumen():
    return respuesta_ok({
        "cantidad": lista.longitud(),
        "vacia": lista.esta_vacia(),
        "total_asientos": total_asientos(),
    })


@app.get("/api/facturas")
def api_listar_facturas():
    return respuesta_ok(cargar_facturas())


@app.get("/api/facturas/<int:numero>")
def api_buscar_factura(numero):
    for factura in cargar_facturas():
        if factura["numero_reserva"] == numero:
            return respuesta_ok(factura)
    return respuesta_error(f"No existe una factura para la reserva #{numero}", 404)


@app.get("/api/pilotos")
def api_listar_pilotos():
    return respuesta_ok(cargar_pilotos())


@app.post("/api/pilotos")
def api_agregar_piloto():
    cuerpo = request.get_json(silent=True) or {}
    nombre = str(cuerpo.get("nombre", "")).strip()
    cargo = str(cuerpo.get("cargo", "Copiloto")).strip()
    if len(nombre) < 3:
        return respuesta_error("Escribe el nombre del piloto")
    piloto = agregar_piloto(nombre, cargo)
    return respuesta_ok(piloto, f"Piloto {nombre} añadido")


@app.delete("/api/pilotos/<int:numero>")
def api_eliminar_piloto(numero):
    eliminado = eliminar_piloto(numero)
    if eliminado is None:
        return respuesta_error("No existe ese piloto", 404)
    return respuesta_ok(eliminado, f"Piloto {eliminado['nombre']} eliminado")


@app.delete("/api/facturas/<int:numero>")
def api_eliminar_factura(numero):
    eliminada = eliminar_factura(numero)
    if eliminada is None:
        return respuesta_error(f"No existe una factura para la reserva #{numero}", 404)
    return respuesta_ok(eliminada, f"Factura AN-F-{numero} eliminada")


@app.get("/api/reservas")
def api_listar():
    clase = request.args.get("clase", "").strip()
    if clase:
        datos = lista.filtrar_por_clase(clase)
    else:
        datos = lista.listar()
    return respuesta_ok(datos)


@app.delete("/api/reservas")
def api_eliminar_todas():
    cantidad = lista.vaciar()
    guardar_lista(lista)
    return respuesta_ok(
        {"eliminadas": cantidad},
        f"Se borraron {cantidad} reservas",
    )


@app.get("/api/reservas/<int:numero>")
def api_buscar_numero(numero):
    p = lista.buscar(numero)
    if p is None:
        return respuesta_error(f"No existe la reserva #{numero}", 404)
    return respuesta_ok(p.a_diccionario(), f"Reserva #{numero} encontrada")


@app.get("/api/asientos/<asiento>")
def api_buscar_asiento(asiento):
    codigo = asiento.strip().upper()
    if not asiento_existe(codigo):
        return respuesta_error(f"El asiento {codigo} no existe en este avión", 404)
    p = lista.buscar_por_asiento(codigo)
    if p is None:
        return respuesta_ok(None, f"El asiento {codigo} está libre")
    return respuesta_ok(p.a_diccionario(), f"En el {codigo} viaja {p.nombre}")


@app.get("/api/cedulas/<cedula>")
def api_buscar_cedula(cedula):
    p = lista.buscar_por_cedula(cedula.strip())
    if p is None:
        return respuesta_error(f"Ningún pasajero tiene la cédula {cedula}", 404)
    return respuesta_ok(p.a_diccionario(), "Pasajero encontrado")


@app.post("/api/reservas")
def api_reservar():
    global siguiente_numero
    cuerpo = request.get_json(silent=True) or {}
    nombre = str(cuerpo.get("nombre", "")).strip()
    cedula = str(cuerpo.get("cedula", "")).strip()
    edad = cuerpo.get("edad", "")
    asiento = str(cuerpo.get("asiento", "")).strip().upper()

    problema = validar_datos_pasajero(nombre, cedula, edad, asiento, validar_cedula=True)
    if problema:
        return respuesta_error(problema)

    if lista.buscar_por_asiento(asiento) is not None:
        return respuesta_error(f"El asiento {asiento} ya está reservado")

    if lista.buscar_por_cedula(cedula) is not None:
        return respuesta_error(f"La cédula {cedula} ya tiene una reserva en este vuelo")

    nuevo = Pasajero(siguiente_numero, nombre, cedula, int(edad), asiento)
    siguiente_numero += 1
    lista.ingresar(nuevo)
    guardar_lista(lista)

    metodo_pago = str(cuerpo.get("metodo_pago", "Sin método de pago")).strip()
    ruta = str(cuerpo.get("ruta", "Guayaquil - Quito")).strip()
    fecha_vuelo = str(cuerpo.get("fecha", VUELO["fecha"])).strip()
    hora_vuelo = str(cuerpo.get("hora", VUELO["hora"])).strip()
    clase = clase_de_asiento(asiento)
    subtotal = 180.00 if clase == "Ejecutiva" else 95.00
    importe_iva = round(subtotal * 0.15, 2)
    total = round(subtotal + importe_iva, 2)
    factura = {
        "numero_factura": f"AN-F-{nuevo.numero}",
        "numero_reserva": nuevo.numero,
        "fecha_emision": datetime.now().isoformat(timespec="seconds"),
        "pasajero": nuevo.nombre,
        "cedula": nuevo.cedula,
        "edad": nuevo.edad,
        "asiento": nuevo.asiento,
        "clase": clase,
        "ruta": ruta,
        "fecha_vuelo": fecha_vuelo,
        "hora_vuelo": hora_vuelo,
        "metodo_pago": metodo_pago if metodo_pago else "Sin método de pago",
        "subtotal": subtotal,
        "iva": importe_iva,
        "total": total,
        "estado": "Emitida",
    }
    guardar_factura(factura)

    avisos = generar_avisos(nuevo.edad, nuevo.asiento)
    return respuesta_ok(
        {**nuevo.a_diccionario(), "factura": factura},
        f"Reserva #{nuevo.numero} creada: {nuevo.nombre} en el asiento {nuevo.asiento}",
        avisos=avisos,
    )


@app.put("/api/reservas/<int:numero>")
def api_modificar(numero):
    cuerpo = request.get_json(silent=True) or {}
    actual = lista.buscar(numero)
    if actual is None:
        return respuesta_error(f"No existe la reserva #{numero}", 404)

    nombre = str(cuerpo.get("nombre", "")).strip()
    edad = cuerpo.get("edad", "")
    asiento = str(cuerpo.get("asiento", "")).strip().upper()

    problema = validar_datos_pasajero(nombre, actual.cedula, edad, asiento, validar_cedula=False)
    if problema:
        return respuesta_error(problema)

    ocupante = lista.buscar_por_asiento(asiento)
    if ocupante is not None and ocupante.numero != numero:
        return respuesta_error(f"El asiento {asiento} ya pertenece a {ocupante.nombre}")

    actualizado = lista.modificar(numero, nombre, int(edad), asiento)
    guardar_lista(lista)

    avisos = generar_avisos(actualizado.edad, actualizado.asiento)
    return respuesta_ok(
        actualizado.a_diccionario(),
        f"Reserva #{numero} actualizada",
        avisos=avisos,
    )


@app.delete("/api/reservas/<int:numero>")
def api_eliminar(numero):
    quitado = lista.eliminar(numero)
    if quitado is None:
        return respuesta_error(f"No existe la reserva #{numero}", 404)
    guardar_lista(lista)
    return respuesta_ok(
        quitado.a_diccionario(),
        f"Reserva #{numero} cancelada: el asiento {quitado.asiento} quedó libre",
    )


@app.post("/api/restaurar")
def api_restaurar():
    global lista, siguiente_numero
    lista, siguiente_numero = restaurar_ejemplo()
    return respuesta_ok(None, "Se restauraron las 12 reservas de ejemplo")


@app.get("/api/progreso")
def api_progreso():
    return respuesta_ok(verificar_metodos())


if __name__ == "__main__":
    app.run(debug=False, port=5050)