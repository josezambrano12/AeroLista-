# Lista enlazada de pasajeros (paso 26)

from vuelo import clase_de_asiento


class Nodo:
    def __init__(self, pasajero):
        self.dato = pasajero
        self.next = None


class ListaPasajeros:
    def __init__(self):
        self.head = None

    def ingresar(self, pasajero):
        nuevo = Nodo(pasajero)
        if self.head is None:
            self.head = nuevo
            return pasajero
        actual = self.head
        while actual.next is not None:
            actual = actual.next
        actual.next = nuevo
        return pasajero

    # --- Los 9 métodos de la lista enlazada ---

    def esta_vacia(self):
        return self.head is None

    def vaciar(self):
        cantidad = self.longitud()
        self.head = None
        return cantidad

    def longitud(self):
        contador = 0
        actual = self.head
        while actual is not None:
            contador += 1
            actual = actual.next
        return contador

    def listar(self):
        resultado = []
        actual = self.head
        while actual is not None:
            resultado.append(actual.dato.a_diccionario())
            actual = actual.next
        return resultado

    def buscar(self, numero):
        numero = int(numero)
        actual = self.head
        while actual is not None:
            if actual.dato.numero == numero:
                return actual.dato
            actual = actual.next
        return None

    def buscar_por_asiento(self, asiento):
        asiento = str(asiento).strip().upper()
        actual = self.head
        while actual is not None:
            if actual.dato.asiento == asiento:
                return actual.dato
            actual = actual.next
        return None

    def buscar_por_cedula(self, cedula):
        cedula = str(cedula).strip()
        actual = self.head
        while actual is not None:
            if actual.dato.cedula == cedula:
                return actual.dato
            actual = actual.next
        return None

    def modificar(self, numero, nombre, edad, asiento):
        pasajero = self.buscar(numero)
        if pasajero is None:
            return None
        pasajero.nombre = str(nombre).strip()
        pasajero.edad = int(edad)
        pasajero.asiento = str(asiento).strip().upper()
        return pasajero

    def eliminar(self, numero):
        numero = int(numero)
        if self.head is None:
            return None
        if self.head.dato.numero == numero:
            eliminado = self.head.dato
            self.head = self.head.next
            return eliminado
        anterior = self.head
        actual = self.head.next
        while actual is not None:
            if actual.dato.numero == numero:
                anterior.next = actual.next
                return actual.dato
            anterior = actual
            actual = actual.next
        return None

    def filtrar_por_clase(self, clase):
        resultado = []
        actual = self.head
        while actual is not None:
            if clase_de_asiento(actual.dato.asiento) == clase:
                resultado.append(actual.dato.a_diccionario())
            actual = actual.next
        return resultado