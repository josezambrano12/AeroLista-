# ==============================================================
#  verificador.py  ·  Pruebas automáticas de tus métodos
# --------------------------------------------------------------
#  Corre pruebas sobre una lista de PRÁCTICA (no toca tus reservas
#  reales) y arma el panel "Progreso del backend" de la página.
#  Estados: ok ✅ · pendiente 🚧 · fallo ❌ · error 💥 · lento ⏳
# ==============================================================

from lista_pasajeros import ListaPasajeros
from pasajero import Pasajero


def verificar_metodos():
    resultados = []

    def probar(nombre_metodo, fn):
        try:
            ok, detalle = fn()
            resultados.append({
                "metodo": nombre_metodo,
                "estado": "ok" if ok else "fallo",
                "detalle": detalle,
            })
        except NotImplementedError:
            resultados.append({
                "metodo": nombre_metodo,
                "estado": "pendiente",
                "detalle": "Aún sin implementar",
            })
        except Exception as e:
            resultados.append({
                "metodo": nombre_metodo,
                "estado": "error",
                "detalle": f"{type(e).__name__}: {e}",
            })

    def test_esta_vacia():
        l = ListaPasajeros()
        if l.esta_vacia() is not True:
            return False, "Debe retornar True cuando la lista está vacía"
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        if l.esta_vacia() is not False:
            return False, "Debe retornar False cuando tiene elementos"
        return True, ""

    def test_longitud():
        l = ListaPasajeros()
        if l.longitud() != 0:
            return False, "Debe retornar 0 en lista vacía"
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        l.ingresar(Pasajero(1002, "Luis", "0987654321", 35, "7D"))
        return (l.longitud() == 2, "Debe retornar 2 tras dos ingresos")

    def test_listar():
        l = ListaPasajeros()
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        l.ingresar(Pasajero(1002, "Luis", "0987654321", 35, "7D"))
        datos = l.listar()
        ok = isinstance(datos, list) and len(datos) == 2 and datos[0]["numero"] == 1001
        return ok, "Debe retornar lista de diccionarios en orden de llegada"

    def test_buscar():
        l = ListaPasajeros()
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        p = l.buscar(1001)
        no = l.buscar(9999)
        ok = p is not None and p.nombre == "Ana" and no is None
        return ok, "Debe retornar el Pasajero o None si no existe"

    def test_buscar_asiento():
        l = ListaPasajeros()
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        p = l.buscar_por_asiento("1a")
        no = l.buscar_por_asiento("12F")
        ok = p is not None and p.numero == 1001 and no is None
        return ok, "Debe encontrar por asiento sin importar mayúsculas/minúsculas"

    def test_buscar_cedula():
        l = ListaPasajeros()
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        p = l.buscar_por_cedula("0912345678")
        no = l.buscar_por_cedula("0000000000")
        ok = p is not None and p.nombre == "Ana" and no is None
        return ok, "Debe encontrar por cédula o retornar None"

    def test_modificar():
        l = ListaPasajeros()
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        mod = l.modificar(1001, "Ana María", 29, "2C")
        ok = mod is not None and mod.nombre == "Ana María" and mod.edad == 29 and mod.asiento == "2C"
        return ok, "Debe actualizar nombre, edad y asiento del nodo"

    def test_eliminar():
        l = ListaPasajeros()
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        l.ingresar(Pasajero(1002, "Luis", "0987654321", 35, "7D"))
        quitado = l.eliminar(1001)
        ok = quitado is not None and quitado.numero == 1001 and l.longitud() == 1
        return ok, "Debe desenlazar el nodo y retornar el pasajero eliminado"

    def test_filtrar():
        l = ListaPasajeros()
        l.ingresar(Pasajero(1001, "Ana", "0912345678", 28, "1A"))
        l.ingresar(Pasajero(1002, "Luis", "0987654321", 35, "7D"))
        ej = l.filtrar_por_clase("Ejecutiva")
        ec = l.filtrar_por_clase("Económica")
        ok = len(ej) == 1 and ej[0]["asiento"] == "1A" and len(ec) == 1 and ec[0]["asiento"] == "7D"
        return ok, "Debe filtrar por 'Ejecutiva' y 'Económica'"

    probar("esta_vacia", test_esta_vacia)
    probar("longitud", test_longitud)
    probar("listar", test_listar)
    probar("buscar", test_buscar)
    probar("buscar_por_asiento", test_buscar_asiento)
    probar("buscar_por_cedula", test_buscar_cedula)
    probar("modificar", test_modificar)
    probar("eliminar", test_eliminar)
    probar("filtrar_por_clase", test_filtrar)

    return resultados