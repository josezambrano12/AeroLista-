# Guardar en JSON (paso 27)
# ==============================================================
#  persistencia.py  ·  Guarda y carga las reservas en JSON
# ==============================================================

import json
import os
from pasajero import Pasajero
from lista_pasajeros import ListaPasajeros

CARPETA_DATA = "data"
RUTA_JSON = os.path.join(CARPETA_DATA, "reservas.json")
RUTA_FACTURACION = os.path.join(CARPETA_DATA, "facturacion.json")
RUTA_PILOTOS = os.path.join(CARPETA_DATA, "pilotos.json")

DATOS_INICIALES = [
    {"numero": 1001, "nombre": "Diana Morales", "cedula": "0912345678", "edad": 24, "asiento": "1A"},
    {"numero": 1002, "nombre": "Carlos Mendoza", "cedula": "0987654321", "edad": 35, "asiento": "2F"},
    {"numero": 1003, "nombre": "Sofía Andrade", "cedula": "1714589632", "edad": 29, "asiento": "3C"},
    {"numero": 1004, "nombre": "Mateo Paredes", "cedula": "1308945120", "edad": 19, "asiento": "7D"},
]


def guardar_reservas(lista_pasajeros):
    """Vuelca la lista enlazada al archivo data/reservas.json."""
    os.makedirs(CARPETA_DATA, exist_ok=True)
    with open(RUTA_JSON, "w", encoding="utf-8") as archivo:
        json.dump(lista_pasajeros.listar(), archivo, ensure_ascii=False, indent=2)


def cargar_reservas(lista_pasajeros):
    """Carga las reservas desde JSON (o crea 4 de ejemplo la primera vez)."""
    os.makedirs(CARPETA_DATA, exist_ok=True)

    if not os.path.exists(RUTA_JSON):
        for item in DATOS_INICIALES:
            lista_pasajeros.ingresar(Pasajero.from_dict(item))
        guardar_reservas(lista_pasajeros)
        return

    try:
        with open(RUTA_JSON, "r", encoding="utf-8") as archivo:
            datos = json.load(archivo)
        for item in datos:
            lista_pasajeros.ingresar(Pasajero.from_dict(item))
    except (json.JSONDecodeError, KeyError):
        guardar_reservas(lista_pasajeros)


def cargar_lista():
    """Crea la lista enlazada y carga reservas desde el JSON existente."""
    lista = ListaPasajeros()
    cargar_reservas(lista)

    siguiente = 1013
    actual = lista.head
    while actual is not None:
        siguiente = max(siguiente, actual.dato.numero + 1)
        actual = actual.next
    return lista, siguiente


def guardar_lista(lista):
    guardar_reservas(lista)


def cargar_facturas():
    os.makedirs(CARPETA_DATA, exist_ok=True)
    if not os.path.exists(RUTA_FACTURACION):
        return []
    try:
        with open(RUTA_FACTURACION, "r", encoding="utf-8") as archivo:
            datos = json.load(archivo)
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def guardar_factura(factura):
    os.makedirs(CARPETA_DATA, exist_ok=True)
    facturas = cargar_facturas()
    facturas.append(factura)
    with open(RUTA_FACTURACION, "w", encoding="utf-8") as archivo:
        json.dump(facturas, archivo, ensure_ascii=False, indent=2)


def eliminar_factura(numero_reserva):
    facturas = cargar_facturas()
    eliminada = None
    restantes = []
    for factura in facturas:
        if int(factura.get("numero_reserva", 0)) == int(numero_reserva):
            eliminada = factura
        else:
            restantes.append(factura)
    if eliminada is not None:
        os.makedirs(CARPETA_DATA, exist_ok=True)
        with open(RUTA_FACTURACION, "w", encoding="utf-8") as archivo:
            json.dump(restantes, archivo, ensure_ascii=False, indent=2)
    return eliminada


def cargar_pilotos():
    os.makedirs(CARPETA_DATA, exist_ok=True)
    if not os.path.exists(RUTA_PILOTOS):
        pilotos_iniciales = [
            {"id": 1, "nombre": "Carlos Mendoza", "cargo": "Piloto comandante"},
            {"id": 2, "nombre": "Ana Torres", "cargo": "Primer oficial"},
        ]
        guardar_pilotos(pilotos_iniciales)
        return pilotos_iniciales
    try:
        with open(RUTA_PILOTOS, "r", encoding="utf-8") as archivo:
            datos = json.load(archivo)
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def guardar_pilotos(pilotos):
    os.makedirs(CARPETA_DATA, exist_ok=True)
    with open(RUTA_PILOTOS, "w", encoding="utf-8") as archivo:
        json.dump(pilotos, archivo, ensure_ascii=False, indent=2)


def agregar_piloto(nombre, cargo):
    pilotos = cargar_pilotos()
    nuevo_id = max((int(piloto.get("id", 0)) for piloto in pilotos), default=0) + 1
    piloto = {"id": nuevo_id, "nombre": nombre.strip(), "cargo": cargo.strip()}
    pilotos.append(piloto)
    guardar_pilotos(pilotos)
    return piloto


def eliminar_piloto(piloto_id):
    pilotos = cargar_pilotos()
    eliminado = next((piloto for piloto in pilotos if int(piloto["id"]) == int(piloto_id)), None)
    if eliminado is None:
        return None
    guardar_pilotos([piloto for piloto in pilotos if int(piloto["id"]) != int(piloto_id)])
    return eliminado


def restaurar_ejemplo():
    ruta_ejemplo = os.path.join(CARPETA_DATA, "ejemplo.json")
    lista = ListaPasajeros()

    with open(ruta_ejemplo, "r", encoding="utf-8") as archivo:
        datos = json.load(archivo)

    for item in datos["reservas"]:
        lista.ingresar(Pasajero.from_dict(item))

    guardar_lista(lista)
    return lista, int(datos["siguiente_numero"])