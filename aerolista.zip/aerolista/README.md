# AeroNova

AeroNova es una aplicación Flask para reservas aéreas. Conserva las reservas en una lista enlazada y las persiste en JSON.

## Funciones principales

- Avión visual con 68 asientos en 2D y 3D.
- Crear, buscar, modificar, eliminar y listar reservas.
- Búsqueda por número, cédula, nombre o asiento.
- Pago obligatorio con tarjeta, débito, transferencia o efectivo.
- Cálculo automático de vuelto en efectivo.
- Facturas persistidas en `data/facturacion.json`.
- Pilotos persistidos en `data/pilotos.json`.
- Pruebas automáticas de los nueve métodos de la lista enlazada.

## Ejecución

```powershell
.\venv\Scriptspython.exe app.py
```

Abrir `http://127.0.0.1:5050`.

## API

- `GET /api/vuelo`
- `GET /api/resumen`
- `GET /api/reservas`
- `POST /api/reservas`
- `PUT /api/reservas/<numero>`
- `DELETE /api/reservas/<numero>`
- `DELETE /api/reservas`
- `GET /api/facturas`
- `DELETE /api/facturas/<numero_reserva>`
- `GET /api/pilotos`
- `POST /api/pilotos`
- `DELETE /api/pilotos/<numero>`
- `GET /api/progreso`
