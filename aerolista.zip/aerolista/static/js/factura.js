async function cargarFacturas() {
  const contenedor = $("#lista-facturas");
  if (!contenedor) return;

  const r = await API.facturas();
  if (!r.ok) {
    contenedor.innerHTML = `<p class="sin-datos">${escapar(r.mensaje)}</p>`;
    return;
  }

  if (!r.datos.length) {
    contenedor.innerHTML = `<p class="sin-datos">No hay facturas emitidas</p>`;
    return;
  }

  contenedor.innerHTML = "";
  r.datos.forEach(factura => {
    const tarjeta = crear("article", "tarjeta-factura");
    tarjeta.innerHTML = `
      <div>
        <strong>${escapar(factura.numero_factura)}</strong>
        <span>Reserva #${factura.numero_reserva} · ${escapar(factura.pasajero)}</span>
        <span>${escapar(factura.fecha_vuelo)} · ${escapar(factura.hora_vuelo)} · ${escapar(factura.asiento)}</span>
        <b>USD ${Number(factura.total).toFixed(2)}</b>
      </div>
      <button type="button" class="btn-factura-borrar" data-factura="${factura.numero_reserva}" title="Eliminar factura">🗑️</button>`;

    tarjeta.querySelector("[data-factura]").addEventListener("click", async () => {
      if (!window.confirm(`¿Eliminar la factura ${factura.numero_factura}?`)) return;
      const eliminado = await API.eliminarFactura(factura.numero_reserva);
      if (!eliminado.ok) return mostrarProblema(eliminado);
      avisar(eliminado.mensaje, "ok");
      await cargarFacturas();
    });

    contenedor.append(tarjeta);
  });
}

const botonFacturas = $$('.pestana[data-pestana="facturas"]')[0];
if (botonFacturas) {
  botonFacturas.addEventListener("click", cargarFacturas);
}
