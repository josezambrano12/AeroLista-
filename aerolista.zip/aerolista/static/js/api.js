const SEGUNDOS_DE_ESPERA = 6;

async function pedir(url, metodo = "GET", cuerpo = null, espera = SEGUNDOS_DE_ESPERA) {
  const controlador = new AbortController();
  const reloj = setTimeout(() => controlador.abort(), espera * 1000);

  const opciones = { method: metodo, signal: controlador.signal, headers: {} };
  if (cuerpo !== null) {
    opciones.headers["Content-Type"] = "application/json";
    opciones.body = JSON.stringify(cuerpo);
  }

  try {
    const respuesta = await fetch(url, opciones);
    return await respuesta.json();
  } catch (error) {
    if (error.name === "AbortError") {
      return {
        ok: false,
        error_codigo: true,
        mensaje: `Flask no respondió en ${espera} s. Revisa que avances con actual = actual.next.`,
      };
    }
    return {
      ok: false,
      error_codigo: true,
      mensaje: "No hay conexión con Flask. ¿Está encendido? → python app.py",
    };
  } finally {
    clearTimeout(reloj);
  }
}

const API = {};
API.vuelo         = ()              => pedir("/api/vuelo");
API.resumen       = ()              => pedir("/api/resumen");
API.listar        = (clase = "")    => pedir("/api/reservas" + (clase ? "?clase=" + encodeURIComponent(clase) : ""));
API.buscarNumero  = (numero)        => pedir("/api/reservas/" + numero);
API.buscarAsiento = (asiento)       => pedir("/api/asientos/" + encodeURIComponent(asiento));
API.buscarCedula  = (cedula)        => pedir("/api/cedulas/" + encodeURIComponent(cedula));
API.reservar      = (datos)         => pedir("/api/reservas", "POST", datos);
API.modificar     = (numero, datos) => pedir("/api/reservas/" + numero, "PUT", datos);
API.eliminar      = (numero)        => pedir("/api/reservas/" + numero, "DELETE");
API.eliminarTodas = ()              => pedir("/api/reservas", "DELETE");
API.restaurar     = ()              => pedir("/api/restaurar", "POST");
API.progreso      = ()              => pedir("/api/progreso", "GET", null, 20);
API.facturas      = ()              => pedir("/api/facturas");
API.eliminarFactura = (numero)     => pedir("/api/facturas/" + numero, "DELETE");
API.pilotos       = ()              => pedir("/api/pilotos");
API.agregarPiloto = (datos)         => pedir("/api/pilotos", "POST", datos);
API.eliminarPiloto = (numero)       => pedir("/api/pilotos/" + numero, "DELETE");