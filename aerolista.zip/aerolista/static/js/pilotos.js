async function cargarPilotos() {
  const contenedor = $("#lista-pilotos");
  if (!contenedor) return;
  const r = await API.pilotos();
  if (!r.ok) {
    contenedor.innerHTML = `<p class="sin-datos">${escapar(r.mensaje)}</p>`;
    return;
  }
  if (!r.datos.length) {
    contenedor.innerHTML = `<p class="sin-datos">No hay pilotos registrados</p>`;
    return;
  }
  contenedor.innerHTML = r.datos.map(piloto => `
    <article class="tarjeta-piloto">
      <div><b>👨‍✈️ ${escapar(piloto.nombre)}</b><span>${escapar(piloto.cargo)}</span></div>
      <button type="button" class="btn-factura-borrar" data-piloto="${piloto.id}" title="Eliminar piloto">🗑️</button>
    </article>`).join("");

  for (const boton of $$("[data-piloto]")) {
    boton.addEventListener("click", async () => {
      const piloto = r.datos.find(item => item.id === Number(boton.dataset.piloto));
      if (!piloto || !window.confirm(`¿Eliminar al piloto ${piloto.nombre}?`)) return;
      const eliminado = await API.eliminarPiloto(piloto.id);
      if (!eliminado.ok) return mostrarProblema(eliminado);
      avisar(eliminado.mensaje, "ok");
      await cargarPilotos();
    });
  }
}

async function enviarPiloto(evento) {
  evento.preventDefault();
  const nombre = $("#piloto-nombre").value.trim();
  const cargo = $("#piloto-cargo").value;
  if (nombre.length < 3) return avisar("Escribe el nombre completo del piloto", "aviso");
  const r = await API.agregarPiloto({ nombre, cargo });
  if (!r.ok) return mostrarProblema(r);
  $("#form-piloto").reset();
  avisar(r.mensaje, "ok");
  await cargarPilotos();
}

$("#form-piloto").addEventListener("submit", enviarPiloto);
$$('.pestana[data-pestana="pilotos"]')[0]?.addEventListener("click", cargarPilotos);
