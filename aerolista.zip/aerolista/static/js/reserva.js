function actualizarAsientoElegido() {
  const salida = $("#reservar-asiento");
  if (estado.seleccionado) {
    salida.textContent = estado.seleccionado;
    salida.classList.remove("vacio");
    $("#reservar-clase").textContent = "Clase " + claseDeAsiento(estado.seleccionado);
  } else {
    salida.textContent = "—";
    salida.classList.add("vacio");
    $("#reservar-clase").textContent = "Elige uno en el avión";
  }
  if (typeof actualizarEfectivo === "function") actualizarEfectivo();
}

const CIUDADES_PROVINCIALES = [
  { codigo: "GYE", nombre: "Guayaquil" },
  { codigo: "UIO", nombre: "Quito" },
  { codigo: "CUE", nombre: "Cuenca" },
  { codigo: "MEC", nombre: "Manta" },
  { codigo: "LOH", nombre: "Loja" },
  { codigo: "GPS", nombre: "Galápagos" },
];

const CIUDADES_INTERNACIONALES = [
  { codigo: "GYE", nombre: "Guayaquil, Ecuador" },
  { codigo: "UIO", nombre: "Quito, Ecuador" },
  { codigo: "BOG", nombre: "Bogotá, Colombia" },
  { codigo: "LIM", nombre: "Lima, Perú" },
  { codigo: "PTY", nombre: "Ciudad de Panamá, Panamá" },
  { codigo: "MIA", nombre: "Miami, Estados Unidos" },
  { codigo: "MAD", nombre: "Madrid, España" },
];

function llenarCiudades(tipo, origenActual = "", destinoActual = "") {
  const ciudades = tipo === "internacional" ? CIUDADES_INTERNACIONALES : CIUDADES_PROVINCIALES;
  const origen = $("#origen-vuelo");
  const destino = $("#destino-vuelo");
  origen.innerHTML = ciudades.map(c => `<option value="${c.codigo}">${c.nombre} (${c.codigo})</option>`).join("");
  destino.innerHTML = ciudades.map(c => `<option value="${c.codigo}">${c.nombre} (${c.codigo})</option>`).join("");
  origen.value = origenActual || (tipo === "internacional" ? "GYE" : "GYE");
  destino.value = destinoActual || (tipo === "internacional" ? "BOG" : "UIO");
  if (origen.value === destino.value) destino.selectedIndex = origen.selectedIndex === 0 ? 1 : 0;
}

function actualizarRutaVuelo() {
  const tipo = $('input[name="tipo-ruta"]:checked')?.value || "provincial";
  const codigoOrigen = $("#origen-vuelo").value;
  const codigoDestino = $("#destino-vuelo").value;
  if (codigoOrigen === codigoDestino) {
    const destino = $("#destino-vuelo");
    destino.selectedIndex = destino.selectedIndex === 0 ? 1 : 0;
  }

  const ciudades = tipo === "internacional" ? CIUDADES_INTERNACIONALES : CIUDADES_PROVINCIALES;
  const origen = ciudades.find(c => c.codigo === $("#origen-vuelo").value);
  const destino = ciudades.find(c => c.codigo === $("#destino-vuelo").value);
  if (origen) {
    $("#ruta-codigo-origen").textContent = origen.nombre.split(",")[0];
    $("#ruta-nombre-origen").textContent = `${origen.codigo} · Origen`;
  }
  if (destino) {
    $("#ruta-codigo-destino").textContent = destino.nombre.split(",")[0];
    $("#ruta-nombre-destino").textContent = `${destino.codigo} · Destino`;
  }

  estado.vuelo.codigo_origen = $("#origen-vuelo").value;
  estado.vuelo.codigo_destino = $("#destino-vuelo").value;
  estado.vuelo.origen = origen?.nombre || "";
  estado.vuelo.destino = destino?.nombre || "";
  estado.vuelo.tipo_ruta = tipo;
  actualizarFechaHoraVuelo();
}

function actualizarFechaHoraVuelo() {
  const fecha = $("#fecha-vuelo").value;
  const hora = $("#hora-vuelo").value || "07:30:00";
  if (fecha) $("#vuelo-fecha").textContent = "📅 " + fecha;
  $("#vuelo-hora").textContent = "🕖 " + hora;
  estado.vuelo.fecha = fecha;
  estado.vuelo.hora = hora;
}

function iniciarRelojSalida(horaInicial = "") {
  const partes = (horaInicial || $("#hora-vuelo").value || "07:30:00").split(":");
  let hora = Number(partes[0]) || 0;
  let minuto = Number(partes[1]) || 0;
  let segundo = Number(partes[2]) || 0;

  if (estado.relojSalida) clearInterval(estado.relojSalida);

  const actualizar = () => {
    segundo++;
    if (segundo >= 60) {
      segundo = 0;
      minuto++;
    }
    if (minuto >= 60) {
      minuto = 0;
      hora = (hora + 1) % 24;
    }

    const texto = [hora, minuto, segundo]
      .map(valor => String(valor).padStart(2, "0"))
      .join(":");

    $("#hora-vuelo").value = texto;
    $("#vuelo-hora").textContent = "🕖 " + texto;
    estado.vuelo.hora = texto;
  };

  actualizar();
  estado.relojSalida = setInterval(actualizar, 1000);
}

function configurarSeleccionVuelo() {
  const hoy = new Date();
  const fechaMinima = new Date(hoy.getTime() - hoy.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const fechaPorDefecto = estado.vuelo?.fecha || fechaMinima;
  const horaPorDefecto = estado.vuelo?.hora || "07:30:00";

  $("#fecha-vuelo").min = fechaMinima;
  $("#fecha-vuelo").value = fechaPorDefecto;
  $("#hora-vuelo").value = horaPorDefecto;
  llenarCiudades("provincial", estado.vuelo?.codigo_origen || "GYE", estado.vuelo?.codigo_destino || "UIO");
  actualizarRutaVuelo();

  for (const radio of $$('input[name="tipo-ruta"]')) {
    radio.addEventListener("change", () => {
      const origen = $("#origen-vuelo").value;
      const destino = $("#destino-vuelo").value;
      const tipo = $('input[name="tipo-ruta"]:checked').value;
      llenarCiudades(tipo, origen, destino);
      actualizarRutaVuelo();
    });
  }
  $("#origen-vuelo").addEventListener("change", actualizarRutaVuelo);
  $("#destino-vuelo").addEventListener("change", actualizarRutaVuelo);
  $("#fecha-vuelo").addEventListener("change", actualizarFechaHoraVuelo);
  $("#hora-vuelo").addEventListener("change", () => {
    actualizarFechaHoraVuelo();
    iniciarRelojSalida($("#hora-vuelo").value);
  });
  $("#hora-vuelo").addEventListener("input", () => {
    actualizarFechaHoraVuelo();
  });
  iniciarRelojSalida(horaPorDefecto);
}

function mostrarBoleto(pasajero) {
  const origen = $("#ruta-codigo-origen").textContent;
  const destino = $("#ruta-codigo-destino").textContent;
  const nombreOrigen = $("#ruta-nombre-origen").textContent;
  const nombreDestino = $("#ruta-nombre-destino").textContent;
  const metodo = $('input[name="metodo-pago"]:checked')?.value || "credito";
  const nombresPago = {
    credito: "Tarjeta de crédito",
    debito: "Tarjeta de débito",
    transferencia: "Transferencia bancaria",
    efectivo: "Efectivo",
  };
  const clase = claseDeAsiento(pasajero.asiento);
  $("#boleto-contenido").innerHTML = `
    <article class="pase ${clase === "Ejecutiva" ? "ejecutiva" : ""}">
      <div class="pase-cuerpo">
        <div class="pase-cabecera"><span>✈ AERONOVA</span><span>PASE DE ABORDAR</span></div>
        <div class="pase-nombre">${escapar(pasajero.nombre)}</div>
        <div class="pase-ruta"><span>${origen}</span><i></i><span>✈</span><i></i><span>${destino}</span></div>
        <div class="pase-detalle">
          <span>Reserva<b>#${pasajero.numero}</b></span>
          <span>Cédula<b>${escapar(pasajero.cedula)}</b></span>
          <span>Edad<b>${pasajero.edad} años</b></span>
          <span>Origen<b>${escapar(nombreOrigen)}</b></span>
          <span>Destino<b>${escapar(nombreDestino)}</b></span>
        </div>
        <div class="boleto-vuelo">
          <span>Fecha de salida<b>${escapar(estado.vuelo.fecha)}</b></span>
          <span>Hora de salida<b>${escapar(estado.vuelo.hora)}</b></span>
          <span>Método de pago<b>${nombresPago[metodo]}</b></span>
          <span>Estado del pago<b>${estado.pagoConfirmado ? "Confirmado" : "Pendiente / no indicado"}</b></span>
        </div>
        <div class="barcode"></div>
      </div>
      <div class="pase-talon"><small>ASIENTO</small><b>${escapar(pasajero.asiento)}</b><em>${clase}</em></div>
    </article>`;
  $("#boleto-modal").showModal();
}

async function reservar(evento) {
  evento.preventDefault();

  const metodo = $('input[name="metodo-pago"]:checked')?.value || "credito";
  if (!estado.pagoConfirmado) {
    $("#panel-pago").hidden = false;
    avisar("Selecciona un método y pulsa Pagar antes de reservar", "aviso");
    $("#btn-confirmar-pago").focus();
    return;
  }
  const pagoAbierto = estado.pagoConfirmado || !$("#panel-pago").hidden;
  if (pagoAbierto && (metodo === "credito" || metodo === "debito")) {
    const numero = $("#numero-tarjeta").value.replace(/\D/g, "");
    const vencimiento = $("#vencimiento-tarjeta").value;
    const cvv = $("#cvv-tarjeta").value;
    if (numero.length !== 16) {
      avisar("Ingresa los 16 dígitos de la tarjeta", "aviso");
      $("#numero-tarjeta").focus();
      return;
    }
    if (!/^\d{2}\/\d{2}$/.test(vencimiento)) {
      avisar("Ingresa el vencimiento con formato MM/AA", "aviso");
      $("#vencimiento-tarjeta").focus();
      return;
    }
    if (cvv.length < 3) {
      avisar("Ingresa el código CVV de la tarjeta", "aviso");
      $("#cvv-tarjeta").focus();
      return;
    }
  }
  if (pagoAbierto && metodo === "efectivo") {
    actualizarEfectivo();
    const total = obtenerTotalPasaje();
    const recibido = Math.max(0, Number($("#efectivo-monto").value) || 0);
    if (recibido < total) {
      avisar(`Falta $${(total - recibido).toFixed(2)} para completar el pago en efectivo`, "aviso");
      $("#pago-efectivo").scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
  }

  if (!estado.seleccionado) {
    avisar("Primero haz clic en un asiento verde del avión", "aviso");
    return;
  }

  const formulario = evento.target;
  const datos = {
    nombre: formulario.nombre.value.trim(),
    cedula: formulario.cedula.value.trim(),
    edad: formulario.edad.value,
    asiento: estado.seleccionado,
    metodo_pago: pagoAbierto
      ? ({
          credito: "Tarjeta de crédito",
          debito: "Tarjeta de débito",
          transferencia: "Transferencia bancaria",
          efectivo: "Efectivo",
        }[metodo])
      : "Sin método de pago",
    ruta: `${$("#ruta-codigo-origen").textContent} - ${$("#ruta-codigo-destino").textContent}`,
    fecha: $("#fecha-vuelo").value,
    hora: $("#hora-vuelo").value,
  };

  const r = await API.reservar(datos);
  if (!r.ok) return mostrarProblema(r);

  avisar(r.mensaje, "ok");
  for (const aviso of r.avisos) avisar(aviso, "aviso");
  const tipoRuta = $('input[name="tipo-ruta"]:checked').value;
  const origenRuta = $("#origen-vuelo").value;
  const destinoRuta = $("#destino-vuelo").value;
  const fechaRuta = $("#fecha-vuelo").value;
  const horaRuta = $("#hora-vuelo").value;
  actualizarRutaVuelo();
  formulario.reset();
  $('input[name="tipo-ruta"][value="' + tipoRuta + '"]').checked = true;
  llenarCiudades(tipoRuta, origenRuta, destinoRuta);
  $("#fecha-vuelo").value = fechaRuta;
  $("#hora-vuelo").value = horaRuta;
  actualizarRutaVuelo();
  iniciarRelojSalida(horaRuta);
  $('input[name="metodo-pago"][value="credito"]').checked = true;
  estado.pagoConfirmado = false;
  $("#abrir-pago").innerHTML = '💳 Elegir método de pago <small>Obligatorio</small>';
  $("#pago-tarjeta").hidden = false;
  $("#pago-transferencia").hidden = true;
  $("#pago-efectivo").hidden = true;
  $("#panel-pago").hidden = true;
  $("#efectivo-monto").value = "0";
  for (const campo of $("#pago-tarjeta").querySelectorAll("input")) {
    campo.required = false;
  }
  estado.seleccionado = null;
  actualizarAsientoElegido();
  await refrescar(r.datos.numero);
  animarAsiento(r.datos.asiento, "recien");
  mostrarBoleto(r.datos);
  mostrarFactura(r.datos.factura);
}

$("#form-reservar").addEventListener("submit", reservar);

for (const boton of $$(".pestana")) {
  boton.addEventListener("click", () => {
    if (boton.dataset.pestana !== "reservar" && estado.seleccionado && !estado.enEdicion) {
      estado.seleccionado = null;
      actualizarAsientoElegido();
      pintarAsientos();
    }
  });
}

$("#boleto-cerrar").addEventListener("click", () => $("#boleto-modal").close());
$("#boleto-imprimir").addEventListener("click", () => window.print());
$("#abrir-pago").addEventListener("click", () => {
  $("#panel-pago").hidden = false;
  $("#cerrar-pago").focus();
});
$("#cerrar-pago").addEventListener("click", () => {
  $("#panel-pago").hidden = true;
  $("#abrir-pago").focus();
});
$("#factura-cerrar").addEventListener("click", () => $("#factura-modal").close());
$("#factura-imprimir").addEventListener("click", () => window.print());