function obtenerTotalPasaje() {
  if (!estado.seleccionado) return 0;
  return claseDeAsiento(estado.seleccionado) === "Ejecutiva" ? 207 : 109.25;
}

function calcularVueltoInteligente(vuelto) {
  const denominaciones = [100, 50, 20, 10];
  let restante = Math.round(vuelto * 100) / 100;
  const desglose = [];
  for (const billete of denominaciones) {
    const cantidad = Math.floor((restante + 0.001) / billete);
    if (cantidad > 0) {
      desglose.push(`${cantidad} × $${billete}`);
      restante = Math.round((restante - cantidad * billete) * 100) / 100;
    }
  }
  return desglose.length ? desglose.join(", ") : "Sin vuelto";
}

function actualizarEfectivo() {
  const total = obtenerTotalPasaje();
  const recibido = Math.max(0, Number($("#efectivo-monto")?.value) || 0);
  const vuelto = recibido - total;

  $("#efectivo-total-pasaje").textContent = `$${total.toFixed(2)}`;
  $("#efectivo-recibido").textContent = `$${recibido.toFixed(2)}`;
  $("#efectivo-vuelto").textContent = vuelto >= 0 ? `$${vuelto.toFixed(2)}` : `Falta $${(-vuelto).toFixed(2)}`;

  const ayuda = $("#efectivo-ayuda");
  ayuda.classList.remove("falta", "completo");
  if (!estado.seleccionado) {
    ayuda.textContent = "Primero selecciona una butaca.";
  } else if (vuelto < 0) {
    ayuda.textContent = "Falta dinero recibido.";
    ayuda.classList.add("falta");
  } else {
    ayuda.textContent = `Vuelto recomendado: ${calcularVueltoInteligente(vuelto)}.`;
    ayuda.classList.add("completo");
  }
}

function configurarMetodosPago() {
  const metodos = $$('input[name="metodo-pago"]');
  const tarjeta = $("#pago-tarjeta");
  const transferencia = $("#pago-transferencia");
  const efectivo = $("#pago-efectivo");

  const actualizarMetodo = () => {
    const metodo = $('input[name="metodo-pago"]:checked')?.value || "credito";
    estado.pagoConfirmado = false;
    $("#abrir-pago").innerHTML = "💳 Elegir método de pago <small>Obligatorio</small>";
    tarjeta.hidden = metodo !== "credito" && metodo !== "debito";
    transferencia.hidden = metodo !== "transferencia";
    efectivo.hidden = metodo !== "efectivo";
    if (metodo === "efectivo") actualizarEfectivo();
  };

  metodos.forEach(metodo => metodo.addEventListener("change", actualizarMetodo));
  $("#efectivo-monto").addEventListener("input", () => {
    $("#efectivo-monto").value = Math.max(0, Number($("#efectivo-monto").value) || 0);
    actualizarEfectivo();
  });

  $("#numero-tarjeta").addEventListener("input", evento => {
    const digitos = evento.target.value.replace(/\D/g, "").slice(0, 16);
    evento.target.value = digitos.replace(/(\d{4})(?=\d)/g, "$1 ");
  });
  $("#vencimiento-tarjeta").addEventListener("input", evento => {
    const digitos = evento.target.value.replace(/\D/g, "").slice(0, 4);
    evento.target.value = digitos.length > 2 ? `${digitos.slice(0, 2)}/${digitos.slice(2)}` : digitos;
  });
  $("#cvv-tarjeta").addEventListener("input", evento => {
    evento.target.value = evento.target.value.replace(/\D/g, "").slice(0, 4);
  });

  $("#btn-confirmar-pago").addEventListener("click", confirmarPago);
  actualizarMetodo();
}

function confirmarPago() {
  const metodo = $('input[name="metodo-pago"]:checked')?.value || "credito";

  if (metodo === "credito" || metodo === "debito") {
    const numero = $("#numero-tarjeta").value.replace(/\D/g, "");
    const vencimiento = $("#vencimiento-tarjeta").value;
    const cvv = $("#cvv-tarjeta").value;
    if (numero.length !== 16) return avisar("Ingresa los 16 dígitos de la tarjeta", "aviso");
    if (!/^\d{2}\/\d{2}$/.test(vencimiento)) return avisar("Ingresa el vencimiento con formato MM/AA", "aviso");
    if (cvv.length < 3) return avisar("Ingresa el código CVV", "aviso");
  }

  if (metodo === "efectivo") {
    actualizarEfectivo();
    const total = obtenerTotalPasaje();
    const recibido = Math.max(0, Number($("#efectivo-monto").value) || 0);
    if (recibido < total) {
      avisar(`Falta $${(total - recibido).toFixed(2)} para completar el pago`, "aviso");
      return;
    }
  }

  estado.pagoConfirmado = true;
  const nombres = {
    credito: "Tarjeta de crédito",
    debito: "Tarjeta de débito",
    transferencia: "Transferencia bancaria",
    efectivo: "Efectivo",
  };
  $("#abrir-pago").innerHTML = `✅ ${nombres[metodo]} <small>Pago confirmado</small>`;
  avisar("Pago confirmado", "ok");
  $("#panel-pago").hidden = true;
}
