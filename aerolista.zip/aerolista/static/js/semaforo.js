function iconoPasajero() {
  return `<svg class="icono-pasajero" viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="12" cy="6.5" r="4.5"/>
            <path d="M3 23c0-5.5 4-9.5 9-9.5s9 4 9 9.5z"/>
          </svg>`;
}

async function cargarReservas() {
  const r = await API.listar();
  estado.porAsiento = {};
  if (r.ok) {
    estado.reservas = r.datos;
    for (const pasajero of r.datos) {
      estado.porAsiento[pasajero.asiento] = pasajero;
    }
    ocultarAviso("#aviso-avion");
  } else {
    estado.reservas = [];
    mostrarAviso("#aviso-avion", r, "El avión todavía no puede ver las reservas.");
  }
  pintarAsientos();
  return r;
}

async function borrarTodasLasReservas() {
  const cantidad = estado.reservas.length;
  if (!window.confirm(`¿Borrar todos los pasajeros? Se eliminarán ${cantidad} reservas y esta acción no se puede deshacer.`)) {
    return;
  }

  const r = await API.eliminarTodas();
  if (!r.ok) return mostrarProblema(r);

  estado.seleccionado = null;
  estado.encontrado = null;
  if (estado.enEdicion) cancelarEdicion();
  actualizarAsientoElegido();
  $("#resultado-buscar").innerHTML = "";
  $("#eliminar-numero").value = "";
  $$(".chip[data-clase]").forEach(chip => {
    chip.classList.toggle("activo", chip.dataset.clase === "");
  });
  avisar(r.mensaje, "ok");
  await refrescar();
}

$("#btn-borrar-todos").addEventListener("click", borrarTodasLasReservas);

function pintarAsientos() {
  for (const boton of $$(".asiento")) {
    const codigo = boton.dataset.asiento;
    const pasajero = estado.porAsiento[codigo];
    const centro = boton.querySelector(".asiento-letra");

    boton.classList.remove("libre", "seleccionado", "ocupado", "encontrado", "editando", "menor");
    boton.removeAttribute("data-estado");

    if (pasajero) {
      boton.classList.add("ocupado");
      boton.dataset.estado = "ocupado";
      if (pasajero.edad < 18) boton.classList.add("menor");
      centro.innerHTML = iconoPasajero();
      boton.setAttribute("aria-label", `Asiento ${codigo}: ${pasajero.nombre}`);
    } else {
      const estadoActual = codigo === estado.seleccionado ? "seleccionado" : "libre";
      boton.classList.add(estadoActual);
      boton.dataset.estado = estadoActual;
      centro.textContent = codigo.slice(-1);
      boton.setAttribute("aria-label", `Asiento ${codigo}: libre`);
    }

    if (codigo === estado.encontrado) boton.classList.add("encontrado");
    if (estado.enEdicion && codigo === estado.enEdicion.asiento) boton.classList.add("editando");
  }
}

function animarAsiento(asiento, animacion) {
  const boton = botonDeAsiento(asiento);
  if (!boton) return;
  boton.classList.remove(animacion);
  void boton.offsetWidth;
  boton.classList.add(animacion);
  setTimeout(() => boton.classList.remove(animacion), 1000);
}

function enfocarAsiento(asiento) {
  const boton = botonDeAsiento(asiento);
  if (boton) boton.scrollIntoView({ behavior: "smooth", block: "center" });
}

function resaltar(asiento) {
  estado.encontrado = asiento;
  pintarAsientos();
  enfocarAsiento(asiento);
}