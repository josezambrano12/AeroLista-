async function cargarTabla() {
  const r = await API.listar(estado.filtroClase);
  const cuerpo = $("#tabla-reservas");
  cuerpo.innerHTML = "";

  if (!r.ok) {
    cuerpo.innerHTML = `<tr><td colspan="5" class="sin-datos">${r.pendiente ? "🚧" : "💥"} ${escapar(r.mensaje)}</td></tr>`;
    return;
  }
  if (!r.datos.length) {
    cuerpo.innerHTML = `<tr><td colspan="5" class="sin-datos">No hay pasajeros en esta clase</td></tr>`;
    return;
  }

  r.datos.forEach((pasajero, posicion) => {
    const fila = crear("tr");
    const claseEjecutiva = claseDeAsiento(pasajero.asiento) === "Ejecutiva" ? "ejecutiva" : "";
    fila.innerHTML = `
      <td>${posicion}</td>
      <td>${pasajero.numero}</td>
      <td>${escapar(pasajero.nombre)}${pasajero.edad < 18 ? " 🧒" : ""}</td>
      <td>${pasajero.edad}</td>
      <td><span class="etiqueta-asiento ${claseEjecutiva}">${escapar(pasajero.asiento)}</span></td>`;
    fila.addEventListener("click", () => resaltar(pasajero.asiento));
    cuerpo.append(fila);
  });
}

function elegirFiltro(evento) {
  const chip = evento.target.closest(".chip");
  if (!chip) return;
  estado.filtroClase = chip.dataset.clase;
  $$(".chip").forEach(item => item.classList.toggle("activo", item === chip));
  cargarTabla();
}

$(".filtros")?.addEventListener("click", elegirFiltro);
